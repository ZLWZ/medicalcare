create definer = root@localhost trigger information_trigger_insert
  after INSERT
  on user
  for each row
begin
	insert into information(uid) values(new.uid);
end;

